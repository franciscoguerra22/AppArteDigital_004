package com.example.BackendArteDigital.models.services;

import java.util.List;

import com.example.BackendArteDigital.models.entities.Servicio;

public interface ServicioService {

    /**
     * Crea un nuevo servicio.
     */
    Servicio crearServicio(Servicio servicio);

    /**
     * Lista todos los servicios disponibles.
     */
    List<Servicio> listarServicios();

    /**
     * Obtiene un servicio por su ID.
     * @throws Exception si no se encuentra el servicio.
     */
    Servicio obtenerServicioPorId(Long id) throws Exception;

    /**
     * Actualiza los datos de un servicio existente.
     * @throws Exception si el servicio no existe.
     */
    Servicio actualizarServicio(Long id, Servicio servicioActualizado) throws Exception;

    /**
     * Desactiva un servicio (por ejemplo, para ocultarlo del catálogo).
     * @throws Exception si el servicio no existe.
     */
    Servicio desactivarServicio(Long id) throws Exception;

    /**
     * Reactiva un servicio previamente desactivado.
     * @throws Exception si el servicio no existe.
     */
    Servicio activarServicio(Long id) throws Exception;

    /**
     * ELIMINA un servicio permanentemente por su ID.
     * @return true si se eliminó con éxito, false si el ID no fue encontrado.
     * @throws Exception si ocurre un error en la base de datos.
     */
    boolean eliminarServicio(Long id) throws Exception; // <-- MÉTODO DE ELIMINACIÓN AÑADIDO

}