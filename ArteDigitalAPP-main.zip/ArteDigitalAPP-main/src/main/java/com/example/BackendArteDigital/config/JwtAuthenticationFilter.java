package com.example.BackendArteDigital.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.BackendArteDigital.models.services.UserDetailsServiceImpl;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    
    // Inicializar el logger
    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {

        final String authHeader = request.getHeader("Authorization");

        // 1. Verificar encabezado
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        final String jwt = authHeader.substring(7); // extrae el token después de "Bearer "
        final String userEmail;

        try {
            // 2. Extraer Email (requiere validación de firma interna en JwtService)
            userEmail = jwtService.extractUsername(jwt);
            
            // 3. Si el email existe y el usuario no está autenticado aún
            if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                
                // 4. Cargar detalles del usuario (Genera la consulta de Hibernate que ya ves)
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);

                // 5. Validar token y autenticar
                if (jwtService.isTokenValid(jwt, userDetails)) {
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null,
                            userDetails.getAuthorities()
                    );

                    authToken.setDetails(
                            new WebAuthenticationDetailsSource().buildDetails(request)
                    );

                    // Registrar autenticación en el contexto
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                    logger.info("✅ Usuario autenticado exitosamente: {}", userEmail);

                } else {
                    logger.warn("❌ Token no válido para el usuario: {}", userEmail);
                }
            }

        } catch (ExpiredJwtException e) {
            logger.warn("❌ Token JWT expirado. {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401
            response.getWriter().write("Token expirado");
            return;
        } catch (JwtException e) {
            // Este catch atrapará fallos de firma (SignatureException) si la clave secreta es incorrecta.
            logger.error("❌ Token JWT inválido o con firma incorrecta. Mensaje: {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_FORBIDDEN); // Enviamos 403, que es lo que el cliente recibe
            response.getWriter().write("Acceso denegado: Token inválido");
            return;
        } catch (Exception e) {
             logger.error("❌ Error inesperado durante la autenticación: {}", e.getMessage(), e);
        }


        // Continuar con el resto de la cadena de filtros
        filterChain.doFilter(request, response);
    }
}