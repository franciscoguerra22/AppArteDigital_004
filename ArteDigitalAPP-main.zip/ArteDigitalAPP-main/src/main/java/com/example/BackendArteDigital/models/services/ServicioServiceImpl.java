package com.example.BackendArteDigital.models.services;

import java.util.List;
import java.util.Optional; // Necesario para el Optional<Servicio>

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.BackendArteDigital.models.entities.Servicio;
import com.example.BackendArteDigital.models.repositories.ServicioRepository;

@Service
public class ServicioServiceImpl implements ServicioService {

    @Autowired
    private ServicioRepository servicioRepository;

    @Override
    @Transactional
    public Servicio crearServicio(Servicio servicio) {
        java.util.Objects.requireNonNull(servicio, "Servicio must not be null");
        return servicioRepository.save(servicio);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Servicio> listarServicios() {
        return servicioRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Servicio obtenerServicioPorId(Long id) throws Exception {
        return servicioRepository.findById(id)
                .orElseThrow(() -> new Exception("Servicio no encontrado con ID: " + id));
    }

    @Override
    @Transactional
    public Servicio actualizarServicio(Long id, Servicio servicioActualizado) throws Exception {
        Servicio servicioExistente = this.obtenerServicioPorId(id);

        servicioExistente.setNombre(servicioActualizado.getNombre());
        servicioExistente.setDescripcion(servicioActualizado.getDescripcion());
        servicioExistente.setPrecio(servicioActualizado.getPrecio());
        servicioExistente.setActivo(servicioActualizado.isActivo());


        return servicioRepository.save(servicioExistente);
    }

    // --- NUEVO MÉTODO AÑADIDO: ELIMINAR SERVICIO ---
    @Override
    @Transactional
    public boolean eliminarServicio(Long id) throws Exception {
        // 1. Verificar si el servicio existe antes de intentar eliminar
        Optional<Servicio> servicioOptional = servicioRepository.findById(id);

        if (servicioOptional.isPresent()) {
            // 2. Si existe, lo eliminamos.
            servicioRepository.deleteById(id);
            return true; // Eliminación exitosa
        } else {
            // 3. Si no existe, retornamos false (o podríamos lanzar una excepción si se prefiere)
            return false;
        }
    }
    // --------------------------------------------------

    @Override
    @Transactional
    public Servicio desactivarServicio(Long id) throws Exception {
        Servicio existente = obtenerServicioPorId(id);
        existente.setActivo(false); // Desactiva el servicio
        return servicioRepository.save(existente);
    }

    @Override
    @Transactional
    public Servicio activarServicio(Long id) throws Exception {
        Servicio existente = obtenerServicioPorId(id);
        existente.setActivo(true); // Activa el servicio
        return servicioRepository.save(existente);
    }
}