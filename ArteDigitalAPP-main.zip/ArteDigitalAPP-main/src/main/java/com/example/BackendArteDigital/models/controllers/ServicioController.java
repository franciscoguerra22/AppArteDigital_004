package com.example.BackendArteDigital.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping; // Importación necesaria
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.BackendArteDigital.models.entities.Servicio;
import com.example.BackendArteDigital.models.services.ServicioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/servicios")
@CrossOrigin(origins = "*") 
public class ServicioController {

    @Autowired
    private ServicioService servicioService;

    // --- Crear servicio ---
    @Operation(summary = "Crear un nuevo servicio",
               description = "Permite a un administrador crear un servicio en la plataforma.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Servicio creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos", content = @Content)
    })
    @PostMapping("/crear")
    public ResponseEntity<?> crearServicio(@RequestBody Servicio servicio) {
        try {
            Servicio nuevoServicio = servicioService.crearServicio(servicio);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoServicio);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear servicio: " + e.getMessage());
        }
    }

    // --- Listar todos los servicios ---
    @Operation(summary = "Listar todos los servicios",
               description = "Devuelve una lista con todos los servicios disponibles (activos o inactivos).")
    @ApiResponse(responseCode = "200", description = "Lista de servicios devuelta correctamente")
    @GetMapping("/listar")
    public ResponseEntity<?> listarServicios() {
        try {
            List<Servicio> servicios = servicioService.listarServicios();
            return ResponseEntity.ok(servicios);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al listar servicios: " + e.getMessage());
        }
    }

    // --- Obtener servicio por ID ---
    @Operation(summary = "Obtener un servicio por ID",
               description = "Devuelve los detalles de un servicio específico buscado por su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Servicio encontrado correctamente"),
        @ApiResponse(responseCode = "404", description = "Servicio no encontrado", content = @Content)
    })
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerServicioPorId(
            @Parameter(description = "ID del servicio a obtener") @PathVariable Long id) {
        try {
            Servicio servicio = servicioService.obtenerServicioPorId(id);
            if (servicio == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Servicio con ID " + id + " no encontrado.");
            }
            return ResponseEntity.ok(servicio);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al obtener servicio: " + e.getMessage());
        }
    }

    // --- Actualizar servicio ---
    @Operation(summary = "Actualizar un servicio existente",
               description = "Actualiza los datos de un servicio según su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Servicio actualizado correctamente"),
        @ApiResponse(responseCode = "404", description = "Servicio no encontrado", content = @Content),
        @ApiResponse(responseCode = "400", description = "Error en los datos enviados", content = @Content)
    })
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarServicio(
            @Parameter(description = "ID del servicio a actualizar") @PathVariable Long id,
            @Parameter(description = "Datos actualizados del servicio") @RequestBody Servicio servicioActualizado) {
        try {
            Servicio actualizado = servicioService.actualizarServicio(id, servicioActualizado);
            if (actualizado == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("No se encontró el servicio con ID " + id);
            }
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al actualizar servicio: " + e.getMessage());
        }
    }
    
    // --- ELIMINAR SERVICIO (BORRADO FÍSICO) ---
    @Operation(summary = "Eliminar un servicio permanentemente",
               description = "Elimina un servicio de la base de datos de forma permanente por su ID. REQUIERE PERMISOS DE ADMINISTRADOR.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Servicio eliminado exitosamente (No Content)"),
        @ApiResponse(responseCode = "404", description = "Servicio no encontrado", content = @Content),
        @ApiResponse(responseCode = "400", description = "Error en la operación", content = @Content)
    })
    @DeleteMapping("/{id}") // <-- ENDPOINT DE ELIMINACIÓN AÑADIDO
    public ResponseEntity<?> eliminarServicio(
            @Parameter(description = "ID del servicio a eliminar") @PathVariable Long id) {
        try {
            boolean eliminado = servicioService.eliminarServicio(id); 
            
            if (eliminado) {
                // HTTP 204 No Content es el estándar para una eliminación exitosa sin devolver datos
                return ResponseEntity.noContent().build(); 
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("No se encontró el servicio con ID " + id + " para eliminar.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al eliminar servicio: " + e.getMessage());
        }
    }
    // ------------------------------------------

    // --- Desactivar servicio ---
    @Operation(summary = "Desactivar un servicio (borrado lógico)",
               description = "Marca un servicio como inactivo sin eliminarlo de la base de datos.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Servicio desactivado correctamente"),
        @ApiResponse(responseCode = "404", description = "Servicio no encontrado", content = @Content)
    })
    @PatchMapping("/{id}/desactivar")
    public ResponseEntity<?> desactivarServicio(@PathVariable Long id) {
        try {
            Servicio desactivado = servicioService.desactivarServicio(id);
            if (desactivado == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("No se encontró el servicio con ID " + id);
            }
            return ResponseEntity.ok(desactivado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al desactivar servicio: " + e.getMessage());
        }
    }

    // --- Activar servicio ---
    @Operation(summary = "Activar un servicio (borrado lógico revertido)",
               description = "Permite reactivar un servicio previamente desactivado.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Servicio activado correctamente"),
        @ApiResponse(responseCode = "404", description = "Servicio no encontrado", content = @Content)
    })
    @PatchMapping("/{id}/activar")
    public ResponseEntity<?> activarServicio(@PathVariable Long id) {
        try {
            Servicio activado = servicioService.activarServicio(id);
            if (activado == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("No se encontró el servicio con ID " + id);
            }
            return ResponseEntity.ok(activado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al activar servicio: " + e.getMessage());
        }
    }
}