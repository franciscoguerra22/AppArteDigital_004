package com.example.BackendArteDigital.models.services;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.BackendArteDigital.config.JwtService;
import com.example.BackendArteDigital.models.entities.Role;
import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.repositories.UsuarioRepository;
import com.example.BackendArteDigital.models.request.AuthResponse;
import com.example.BackendArteDigital.models.request.LoginRequest;
import com.example.BackendArteDigital.models.request.RegistroRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    /**
     * LOGIN
     */
   public AuthResponse login(LoginRequest request) {

    // --- VALIDACIONES MANUALES ---
    if (request.getEmail() == null || request.getEmail().isBlank()) {
        throw new RuntimeException("El email es obligatorio");
    }

    if (request.getPassword() == null || request.getPassword().isBlank()) {
        throw new RuntimeException("La contraseña es obligatoria");
    }

    // --- AUTENTICACIÓN ---
    try {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );
    } catch (Exception e) {
        // Capturamos BadCredentials y lanzamos mensaje personalizado
        if (e.getMessage().contains("Bad credentials")) {
            throw new RuntimeException("Contraseña inválida");
        }
        throw new RuntimeException("Error al iniciar sesión");
    }

    // --- BUSCAR USUARIO ---
    Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new RuntimeException("Usuario no registrado"));

    // --- GENERAR TOKEN ---
    String jwtToken = jwtService.generateToken(usuario);

    // --- RESPUESTA ---
    return AuthResponse.builder()
            .token(jwtToken)
            .role(usuario.getRole().name())
            .nombre(usuario.getNombreCompleto()) // por si quieres mostrarlo en Android
            .build();
}


    /**
     * REGISTRO
     */
    public AuthResponse register(RegistroRequest request) {

        // VALIDACIONES =======================

        if (request.getNombreCompleto() == null || request.getNombreCompleto().isBlank()) {
            throw new RuntimeException("El nombre completo es obligatorio");
        }

        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new RuntimeException("El email es obligatorio");
        }

        if (!request.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new RuntimeException("El email no tiene un formato válido");
        }

        if (request.getPassword() == null || request.getPassword().isBlank()) {
            throw new RuntimeException("La contraseña es obligatoria");
        }

        if (request.getPassword().length() < 6) {
            throw new RuntimeException("La contraseña debe tener al menos 6 caracteres");
        }

        // Correo existente
        if (usuarioRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("El correo ya está registrado");
        }

        // ====================================

        Usuario usuario = new Usuario();
        usuario.setNombreCompleto(request.getNombreCompleto());
        usuario.setEmail(request.getEmail());
        usuario.setPassword(passwordEncoder.encode(request.getPassword()));
        usuario.setRole(Role.ROLE_USER);

        usuarioRepository.save(usuario);

        String jwtToken = jwtService.generateToken(usuario);

        return AuthResponse.builder()
                .token(jwtToken)
                .role(usuario.getRole().name())
                .build();
    }
}
