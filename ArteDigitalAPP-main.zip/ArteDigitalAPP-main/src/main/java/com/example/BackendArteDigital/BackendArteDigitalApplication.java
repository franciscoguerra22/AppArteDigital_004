package com.example.BackendArteDigital;

// --- IMPORTACIONES NECESARIAS ---
import com.example.BackendArteDigital.models.entities.Role;
import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.repositories.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
// --- FIN IMPORTACIONES ---

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class BackendArteDigitalApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendArteDigitalApplication.class, args);
    }

    // --- 1. BEAN PARA EL CODIFICADOR DE CONTRASEÑAS ---
    /**
     * Define el bean para el PasswordEncoder, que usará el algoritmo BCrypt.
     * Spring lo usará automáticamente para proteger las contraseñas.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // --- 2. BEAN PARA CREAR USUARIO ADMIN AL INICIAR ---
    /**
     * Este bean se ejecuta una vez que la aplicación arranca.
     * Revisa si el usuario admin ya existe; si no, lo crea.
     */
    @Bean
    public CommandLineRunner createAdminUser(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            // Revisa si el admin ya existe en la BD
            if (usuarioRepository.findByEmail("admin@artedigital.cl").isEmpty()) {
                
                System.out.println(">>> Creando usuario ADMIN de prueba...");
                
                Usuario admin = new Usuario();
                admin.setEmail("admin@artedigital.cl");
                admin.setNombreCompleto("Administrador");
                
                // --- IMPORTANTE: Codifica la contraseña ---
                // La contraseña en texto plano será "admin123"
                admin.setPassword(passwordEncoder.encode("admin123"));
                
                admin.setRole(Role.ROLE_ADMIN);
                // (Los otros campos como teléfono, etc., pueden ser null)

                usuarioRepository.save(admin);
                
                System.out.println(">>> Usuario ADMIN creado: admin@artedigital.cl / (pass: admin123)");
            
            } else {
                System.out.println(">>> El usuario ADMIN ya existe.");
            }
        };
    }
}