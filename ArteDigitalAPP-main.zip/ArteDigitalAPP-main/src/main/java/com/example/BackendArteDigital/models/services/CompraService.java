package com.example.BackendArteDigital.models.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // ⬅️ Recomendable para asegurar las transacciones

import com.example.BackendArteDigital.models.dto.CompraResponse; 
import com.example.BackendArteDigital.models.entities.Compra;
import com.example.BackendArteDigital.models.entities.Servicio;
import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.repositories.CompraRepository;

@Service
public class CompraService {

    @Autowired
    private CompraRepository compraRepository;
    
    // ⬅️ Necesitas esto para buscar los servicios por ID
    @Autowired 
    private ServicioService servicioService; 

    /**
     * Registra una nueva compra para un solo servicio. Usado internamente por registrarCompras.
     */
    public Compra registrarCompra(Usuario usuario, Servicio servicio) {
        Compra nuevaCompra = new Compra();

        nuevaCompra.setUsuario(usuario);
        nuevaCompra.setServicio(servicio);
        nuevaCompra.setFechaCompra(LocalDateTime.now());    // Fecha actual
        nuevaCompra.setValor(servicio.getPrecio());         // Precio del servicio
        nuevaCompra.setEstado("Pagado");                    // Estado inicial

        return compraRepository.save(nuevaCompra);
    }
    
    /**
     * 🎯 NUEVO MÉTODO: Registra múltiples compras para un usuario (desde el carrito).
     * @param usuario El usuario autenticado.
     * @param servicioIds La lista de IDs de servicios a comprar.
     * @return Una lista de IDs de servicios que fallaron en el registro.
     */
    @Transactional
    public List<Long> registrarCompras(Usuario usuario, List<Long> servicioIds) {
        List<Long> serviciosFallidos = new java.util.ArrayList<>();
        
        // Usamos un bucle para procesar cada servicio del carrito
        for (Long servicioId : servicioIds) {
            try {
                // 1. Obtener el servicio y validar si existe y está activo
                Servicio servicio = servicioService.obtenerServicioPorId(servicioId); 
                
                // Validación estricta: si no existe O no está activo, se considera un fallo
                if (servicio == null || !servicio.isActivo()) {
                    serviciosFallidos.add(servicioId);
                    continue; // Pasa al siguiente ítem del carrito
                }
                
                // 2. Registrar la compra para ese servicio
                registrarCompra(usuario, servicio);

            } catch (Exception e) {
                // Captura cualquier error durante la creación (ej. DB)
                serviciosFallidos.add(servicioId);
            }
        }
        return serviciosFallidos;
    }


    /**
     * Lista las compras de un usuario y las mapea al DTO de respuesta.
     */
    public List<CompraResponse> listarMisCompras(Usuario usuario) {
        List<Compra> compras = compraRepository.findByUsuario(usuario);
        
        // Mapea la lista de Entidades (Compra) a la lista de DTOs (CompraResponse)
        return compras.stream()
            .map(this::mapToCompraResponse)
            .collect(Collectors.toList());
    }

    /**
     * Lista todas las compras de un usuario específico (por ID)
     */
    public List<Compra> listarComprasPorUsuario(Usuario usuario) {
        return compraRepository.findByUsuarioId(usuario.getId());
    }

    /**
     * Lista todas las compras registradas (solo para admin)
     */
    public List<Compra> listarTodasCompras() {
        return compraRepository.findAll();
    }
    
    /**
     * Método de mapeo de Compra Entity a CompraResponse DTO
     */
    private CompraResponse mapToCompraResponse(Compra compra) {
        return new CompraResponse(
            compra.getId(),
            compra.getUsuario().getId(),
            compra.getServicio().getId(),
            compra.getValor(),
            compra.getFechaCompra(),
            compra.getEstado(),
            // Incluye el nombre del servicio para que sea fácil de mostrar en la app
            compra.getServicio().getNombre() 
        );
    }
}