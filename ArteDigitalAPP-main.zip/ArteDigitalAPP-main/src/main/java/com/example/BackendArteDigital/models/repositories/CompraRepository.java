package com.example.BackendArteDigital.models.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.BackendArteDigital.models.entities.Compra;
import com.example.BackendArteDigital.models.entities.Usuario;

@Repository
public interface CompraRepository extends JpaRepository<Compra, Long> {

    // Encuentra todas las compras de un usuario usando su entidad
    List<Compra> findByUsuario(Usuario usuario);

    // Encuentra todas las compras de un usuario usando su ID
    List<Compra> findByUsuarioId(Long usuarioId);

    // Encuentra compras filtradas por estado (por ejemplo, "Pagado", "Pendiente")
    List<Compra> findByEstado(String estado);
}
