package com.example.BackendArteDigital.models.dto;

import java.time.LocalDateTime;

// Nota: Asumo que usas Lombok (@Data, @Getter, @Setter) o creas constructores
public class CompraResponse {

    private Long id;
    private Long usuarioId;
    private Long servicioId;
    private Double valor;
    private LocalDateTime fechaCompra;
    private String estado;
    private String nombreServicio; // Campo extra útil para el front-end

    // Constructor para mapeo
    public CompraResponse(Long id, Long usuarioId, Long servicioId, Double valor, LocalDateTime fechaCompra, String estado, String nombreServicio) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.servicioId = servicioId;
        this.valor = valor;
        this.fechaCompra = fechaCompra;
        this.estado = estado;
        this.nombreServicio = nombreServicio;
    }
    
    // Asumiendo que usas Lombok, sino añade getters/setters aquí
    public Long getId() { return id; }
    public Long getUsuarioId() { return usuarioId; }
    public Long getServicioId() { return servicioId; }
    public Double getValor() { return valor; }
    public LocalDateTime getFechaCompra() { return fechaCompra; }
    public String getEstado() { return estado; }
    public String getNombreServicio() { return nombreServicio; }
}