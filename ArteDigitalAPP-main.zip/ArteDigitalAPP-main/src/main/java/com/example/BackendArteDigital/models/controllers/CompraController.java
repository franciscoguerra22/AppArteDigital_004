package com.example.BackendArteDigital.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.BackendArteDigital.models.dto.CompraResponse;
import com.example.BackendArteDigital.models.entities.Compra;
import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.services.CompraService;
import com.example.BackendArteDigital.models.services.ServicioService;
import com.example.BackendArteDigital.models.services.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/compras")
@CrossOrigin(origins = "*")
public class CompraController {

    @Autowired
    private CompraService compraService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ServicioService servicioService;

    @Operation(
            summary = "Registrar una nueva compra (SIMULACIÓN)",
            description = "Crea un registro de compra para uno o más servicios. SIMULADO para el examen: Usa usuario admin por defecto."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Compra(s) registrada(s) exitosamente"),
            @ApiResponse(responseCode = "400", description = "Uno o más servicios no pudieron registrarse", content = @Content),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor", content = @Content)
    })
    @PostMapping("/registrar")
    public ResponseEntity<?> registrarCompra(@RequestBody List<Long> servicioIds) {

        try {
            // Usuario por defecto para simulación
            String userEmail = "admin@artedigital.cl";
            Usuario usuario = usuarioService.obtenerUsuarioPorEmail(userEmail);

            if (usuario == null) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("El usuario de simulación (admin@artedigital.cl) no existe en la BD.");
            }

            List<Long> serviciosFallidos = compraService.registrarCompras(usuario, servicioIds);

            if (serviciosFallidos.isEmpty()) {
                return ResponseEntity.status(HttpStatus.CREATED).body("Compra completada exitosamente.");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Compra incompleta. IDs fallidos: " + serviciosFallidos.toString());
            }

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al registrar la compra: " + e.getMessage());
        }
    }

    @Operation(
            summary = "Listar las compras del usuario autenticado (o simulado)",
            description = "Devuelve el historial de compras. Usa autenticación si existe; si no, usa un usuario de simulación."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente"),
            @ApiResponse(responseCode = "401", description = "Usuario no autenticado", content = @Content)
    })
    @GetMapping("/miscompras")
    public ResponseEntity<List<CompraResponse>> obtenerMisCompras(Authentication authentication) {

        try {
            String userEmail;

            if (authentication == null || !authentication.isAuthenticated()) {
                userEmail = "admin@artedigital.cl";
            } else {
                userEmail = authentication.getName();
            }

            Usuario usuario = usuarioService.obtenerUsuarioPorEmail(userEmail);

            if (usuario == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
            }

            List<CompraResponse> compras = compraService.listarMisCompras(usuario);
            return ResponseEntity.ok(compras);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Operation(
            summary = "Listar compras por usuario",
            description = "Devuelve el historial completo de compras para un usuario por su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado", content = @Content)
    })
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> listarComprasPorUsuario(
            @Parameter(description = "ID del usuario") @PathVariable Long usuarioId) {

        try {
            Usuario usuario = usuarioService.obtenerUsuarioPorId(usuarioId);

            if (usuario == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado.");
            }

            List<Compra> compras = compraService.listarComprasPorUsuario(usuario);
            return ResponseEntity.ok(compras);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al obtener las compras: " + e.getMessage());
        }
    }

    @Operation(
            summary = "Listar todas las compras (admin)",
            description = "Devuelve todas las compras registradas en el sistema."
    )
    @ApiResponse(responseCode = "200", description = "Lista completa obtenida")
    @GetMapping("/todas")
    public ResponseEntity<?> listarTodasCompras() {
        try {
            List<Compra> compras = compraService.listarTodasCompras();
            return ResponseEntity.ok(compras);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al obtener todas las compras: " + e.getMessage());
        }
    }
}
