package com.example.BackendArteDigital.models.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.BackendArteDigital.models.entities.Compra;
import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.repositories.CompraRepository;
import com.example.BackendArteDigital.models.repositories.UsuarioRepository;
import com.example.BackendArteDigital.models.request.LoginRequest;
import com.example.BackendArteDigital.models.request.RegistroRequest;

import lombok.NonNull;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CompraRepository compraRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // --- REGISTRO DE USUARIO ---
    public Usuario registrarUsuario(RegistroRequest registroRequest) throws Exception {

        if (registroRequest.getNombreCompleto() == null || registroRequest.getNombreCompleto().isBlank()) {
            throw new Exception("El nombre es obligatorio");
        }

        if (registroRequest.getEmail() == null || registroRequest.getEmail().isBlank()) {
            throw new Exception("El email es obligatorio");
        }

        if (registroRequest.getPassword() == null || registroRequest.getPassword().isBlank()) {
            throw new Exception("La contraseña es obligatoria");
        }

        if (usuarioRepository.findByEmail(registroRequest.getEmail()).isPresent()) {
            throw new Exception("El email ya está en uso");
        }

        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombreCompleto(registroRequest.getNombreCompleto());
        nuevoUsuario.setEmail(registroRequest.getEmail());
        nuevoUsuario.setPassword(passwordEncoder.encode(registroRequest.getPassword()));

        return usuarioRepository.save(nuevoUsuario);
    }


    // --- LOGIN DE USUARIO ---
    public String loginUsuario(LoginRequest loginRequest) throws Exception {
        Usuario usuario = usuarioRepository.findByEmail(loginRequest.getEmail())
                .orElseThrow(() -> new Exception("Credenciales inválidas: Usuario no encontrado."));

        if (!passwordEncoder.matches(loginRequest.getPassword(), usuario.getPassword())) {
            throw new Exception("Credenciales inválidas: Contraseña incorrecta.");
        }

        return "Inicio de sesión exitoso";
    }

    // --- OBTENER USUARIO POR EMAIL (NUEVO MÉTODO) ---
    public Usuario obtenerUsuarioPorEmail(String email) throws Exception {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("El email no puede ser nulo.");
        }
        return usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new Exception("Usuario no encontrado con email: " + email));
    }


    // --- OBTENER USUARIO POR ID ---
    public Usuario obtenerUsuarioPorId(Long id) throws Exception {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser nulo.");
        }
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new Exception("Usuario no encontrado con id: " + id));
    }

    // --- ACTUALIZAR USUARIO ---
    public Usuario actualizarUsuario(Long usuarioId, RegistroRequest registroRequest) throws Exception {
        if (usuarioId == null) {
            throw new Exception("El ID del usuario no puede ser nulo.");
        }
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new Exception("Usuario no encontrado."));

        usuario.setNombreCompleto(registroRequest.getNombreCompleto());
        usuario.setEmail(registroRequest.getEmail());

        if (registroRequest.getPassword() != null && !registroRequest.getPassword().isEmpty()) {
            usuario.setPassword(passwordEncoder.encode(registroRequest.getPassword()));
        }

        return usuarioRepository.save(usuario);
    }

    // --- LISTAR TODOS LOS USUARIOS ---
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    // --- OBTENER TODAS LAS COMPRAS DE UN USUARIO ---
    public List<Compra> obtenerComprasUsuario(@NonNull Long usuarioId) throws Exception {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new Exception("Usuario no encontrado."));

        return compraRepository.findByUsuario(usuario);
    }

    // --- OBTENER TODAS LAS COMPRAS (ADMIN/ARTISTA) ---
    public List<Compra> obtenerTodasLasCompras() {
        return compraRepository.findAll();
    }
}