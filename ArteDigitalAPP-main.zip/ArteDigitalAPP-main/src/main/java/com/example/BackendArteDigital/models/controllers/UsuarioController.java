package com.example.BackendArteDigital.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.BackendArteDigital.models.entities.Usuario;
import com.example.BackendArteDigital.models.request.RegistroRequest;
import com.example.BackendArteDigital.models.services.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*") // Permite peticiones desde cualquier origen (Android + Web)
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // === LISTAR TODOS LOS USUARIOS (solo admin) ===
    // 🔒 Este endpoint debería protegerse con rol ADMIN en SecurityConfig si lo usas en producción.
    @GetMapping("/listar")
    public ResponseEntity<List<Usuario>> listarTodosLosUsuarios() {
        List<Usuario> usuarios = usuarioService.listarTodos();
        return ResponseEntity.ok(usuarios);
    }

    // === OBTENER USUARIO POR ID ===
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.obtenerUsuarioPorId(id);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al obtener usuario: " + e.getMessage());
        }
    }

    // === ACTUALIZAR PERFIL DE USUARIO ===
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody RegistroRequest datosActualizados) {
        try {
            Usuario actualizado = usuarioService.actualizarUsuario(id, datosActualizados);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al actualizar usuario: " + e.getMessage());
        }
    }

}
