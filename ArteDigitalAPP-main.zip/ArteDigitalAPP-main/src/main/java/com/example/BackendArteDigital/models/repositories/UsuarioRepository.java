package com.example.BackendArteDigital.models.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;

import com.example.BackendArteDigital.models.entities.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // 🔹 Buscar usuario por email
    Optional<Usuario> findByEmail(String email);

    // 🔹 Método personalizado para obtener usuario por ID (sin Optional)
    default Usuario getUsuarioByIdOrThrow(@NonNull Long id) {
        return findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }
}
