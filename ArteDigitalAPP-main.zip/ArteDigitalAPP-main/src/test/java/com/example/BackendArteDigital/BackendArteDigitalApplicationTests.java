package com.example.BackendArteDigital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendArteDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
